VoxBridge 1.0.0 for Windows
===========================

VoxBridge turns your phone into a microphone for Windows. Audio travels
directly over your local network; nothing is uploaded to a server.

Quick start
  1. Start VoxBridge (Start menu or desktop shortcut).
  2. Install VoxBridge on your phone and open it.
  3. Keep both devices on the same Wi-Fi. If the phone asks for a code, type
     the four digits shown in the VoxBridge window.
  4. In Zoom, Teams, Discord or OBS choose "CABLE Output (VB-Audio Virtual
     Cable)" as the microphone.

A virtual audio cable is required before other apps can see VoxBridge as a
microphone. Open Studio in the app and choose "Set up virtual mic"; VoxBridge
downloads the official VB-CABLE installer, verifies its signature and asks
Windows for permission once.

Uninstall
  Windows Settings > Apps > VoxBridge > Uninstall, or run
  VoxBridge-Uninstall.exe from the install folder.

License: MIT. Third-party notices are in licenses/.
